# websnip

Capture a specific DOM element as an image.
